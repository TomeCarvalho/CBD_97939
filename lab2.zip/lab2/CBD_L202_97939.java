// NMEC: 97939
// 1. Liste todos os documentos da coleção.
db.restaurants.find()
// 3772

// 2. Apresente os campos restaurant_id, nome, localidade e gastronomia para todos os documentos da coleção.
db.restaurants.find({},{"restaurant_id":1,"nome":1,"localidade":1,"gastronomia":1})
// {
//     _id: ObjectId("617a6f9bc02beedac108cadd"),
//     localidade: 'Manhattan',
//     gastronomia: 'Turkish',
//     nome: 'The Country Cafe',
//     restaurant_id: '40362715'
// }

// 3. Apresente os campos restaurant_id, nome, localidade e código postal (zipcode), mas exclua o campo _id de todos os documentos da coleção.
db.restaurants.find({},{"restaurant_id":1,"nome":1,"localidade":1,"address.zipcode":1,"_id":0})
// {
//     address: { zipcode: '10005' },
//     localidade: 'Manhattan',
//     nome: 'The Country Cafe',
//     restaurant_id: '40362715'
// }

// 4. Indique o total de restaurantes localizados no Bronx
db.restaurants.find({"localidade":"Bronx"}).count()
// 309

// 5. Apresente os primeiros 15 restaurantes localizados no Bronx, ordenados por ordem crescente de nome.
db.restaurants.find({"localidade":"Bronx"}).limit(15).sort("nome")

// 6. Liste todos os restaurantes que tenham pelo menos um score superior a 85
db.restaurants.find({"grades.score":{$gt:85}})

// 7. Encontre os restaurantes que obtiveram uma ou mais pontuações (score) entre [80 e 100].
db.restaurants.find({ "grades": { $elemMatch: { "score": { $gte: 80, $lte: 100 } } } })
// 4

// 8. Indique os restaurantes com latitude inferior a -95,7.
db.restaurants.find({"address.coord.0": {$lt: -95.7}})
// 3

// 9. Indique os restaurantes que não têm gastronomia "American", tiveram uma (ou mais) pontuação superior a 70 e estão numa latitude inferior a -65.
db.restaurants.find({"gastronomia":{$ne:"American"}, "grades.score":{$gt:70}, "address.coord.0":{$lt:-65}})
// 5

// 10.Liste o restaurant_id, o nome, a localidade e gastronomia dos restaurantes cujo nome começam por "Wil"
db.restaurants.find({"nome":/^Wil.*/}, {"nome":1, "localidade":1, "gastronomia":1})
// 3
// note: /pattern/ is regex in JavaScript, we could alternatively write it as:
// db.restaurants.find({"nome":{$regex: "^Wil.*"}}, {"nome":1, "restaurand_id":1, "localidade":1, "gastronomia":1})

// 11. Liste o nome, a localidade e a gastronomia dos restaurantes que pertencem ao Bronx e cuja gastronomia é do tipo "American" ou "Chinese"
db.restaurants.find({ "localidade": "Bronx", "gastronomia": { $in: ["American", "Chinese"] } }, { "nome": 1, "localidade": 1, "gastronomia": 1 })
// 91

// 12. Liste o restaurant_id, o nome, a localidade e a gastronomia dos restaurantes localizados em "Staten Island", "Queens", ou "Brooklyn".
db.restaurants.find({"localidade": {$in: ["Staten Island", "Queens", "Brooklyn"]}}, {"restaurant_id":1, "localidade":1, "gastronomia":1})

// 13. Liste o nome, a localidade, o score e gastronomia dos restaurantes que alcançaram sempre pontuações inferiores ou igual a 3.
